<!-- Copyrights 2023 Developed by Rusdi -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Donasi</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<style type="text/css">
    /* Gaya untuk judul tabel */
.donation-history h2 {
  margin-bottom: 1rem;
  text-align: center;
  color: #555;
}

/* Gaya untuk tabel responsif pada perangkat mobile */
@media screen and (max-width: 600px) {
  table {
    font-size: 12px;
  }
}
</style>
<body>
    <header>
        <nav class="main-menu">
            <img src="img/logo.png">
            <ul>
                <li><a href="index.html">Beranda</a></li>
                <li><a href="tentang.php">Tentang</a></li>
                <li><a href="donasi.html">Donasi</a></li>
                <li><a href="riwayat_donasi.php">Riwayat Donasi</a></li>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section class="donation-history">
            <h2>Riwayat Donasi</h2>
            <table>
                <thead>
                    <tr>
                        <th>No. </th>
                        <th>Pengirim</th>
                        <th>Tanggal Donasi </th>
                        <th>Jumlah </th>
                        <th>Metode Pembayaran </th>
                        <th>Pesan </th>
                    </tr>
                </thead>
                <tbody>
                    <?php include 'fetch_donations.php'; ?> <!-- Memanggil skrip PHP untuk mengambil data donasi -->
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p class="gans">Copyrights &copy; 2023 Portal Donasi </p>
    </footer>
</body>
</html>
