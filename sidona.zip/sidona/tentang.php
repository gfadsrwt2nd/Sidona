<!-- Copyrights 2023 Developed by Rusdi -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="main-menu">
            <img src="img/logo.png">
            <ul>
                <li><a href="index.html">Beranda</a></li>
                <li><a href="#">Tentang</a></li>
                <li><a href="donasi.html">Donasi</a></li>
                <li><a href="riwayat_donasi.php">Riwayat Donasi</a></li>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section class="about-us">
            <h2>Tentang Kami</h2>
            <p class="rin">
                Selamat datang di website donasi kami! Kami adalah sebuah platform donasi online yang bertujuan untuk membantu berbagai kegiatan sosial dan amal.
                Kami berkomitmen untuk menyediakan solusi donasi yang mudah, aman, dan transparan bagi para pengguna kami.
                Melalui website ini, Anda dapat berdonasi untuk berbagai kampanye dan membantu mereka yang membutuhkan.
                Terima kasih atas dukungan Anda!
            </p>
        </section>
    </main>

    <footer>
        <p class="gans">Copyrights &copy; 2023 Portal Donasi </p>
    </footer>
</body>
</html>
