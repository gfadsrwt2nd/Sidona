<?php
// Sertakan file koneksi.php (ganti dengan lokasi dan nama file koneksi sesuai dengan proyek Anda)
include 'koneksi.php';

// Query untuk mengambil daftar gambar dari tabel "image_gallery"
$sql = "SELECT * FROM image_gallery";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<img src='" . $row['image_url'] .  "'>";
    }
} else {
    echo "<p>Tidak ada gambar dalam galeri.</p>";
}

// Tutup koneksi
$conn->close();
?>
