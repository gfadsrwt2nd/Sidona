<?php
// Konfigurasi koneksi database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sidona';

// Buat koneksi ke database
$conn = new mysqli($host, $username, $password, $database);

// Periksa koneksi
if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}

// Pastikan form telah dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data yang dikirim dari form
    $amount = $_POST['amount'];
    $paymentMethodId = $_POST['payment_method'];
    $message = $_POST['message'];
    $senderName = $_POST['sender_name'];

    // Pastikan data sudah sesuai (validasi data jika perlu)

    // Ambil user_id dari sesi atau form (sesuaikan dengan sistem login Anda)
    $userId = 1; // Contoh: seharusnya diambil dari sesi atau form

    // Simpan data ke database
    $sql = "INSERT INTO donations (user_id, amount, payment_method, message, sender_name) VALUES ('$userId', '$amount', '$paymentMethodId', '$message', '$senderName')";
    if ($conn->query($sql) === TRUE) {
        echo "Donasi berhasil disimpan!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Tutup koneksi
$conn->close();
?>
