<!-- Copyrights 2023 Developed by Rusdi -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="main-menu">
            <img src="img/logo.png">
            <ul>
                <li><a href="index.html">Beranda</a></li>
                <li><a href="tentang.php">Tentang</a></li>
                <li><a href="donasi.html">Donasi</a></li>
                <li><a href="riwayat_donasi.php">Riwayat Donasi</a></li>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section class="contact">
            <h2>Hubungi Kami</h2>
            <p>Jika Anda memiliki pertanyaan atau ingin memberikan umpan balik, silakan hubungi kami melalui formulir di bawah ini:</p>
            <form action="proses_kontak.php" method="POST">
                <label for="name">Nama:</label>
                <input type="text" id="name" name="name" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                
                <label for="message">Pesan:</label>
                <textarea id="message" name="message" rows="4" required></textarea>
                
                <button type="submit">Kirim Pesan</button>
            </form>
        </section>
    </main>

    <footer>
        <p class="gans">Copyrights &copy; 2023 Portal Donasi </p>
    </footer>
</body>
</html>
