<!-- Copyrights 2023 Developed by Rusdi -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri Gambar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="main-menu">
            <img src="img/logo.png">
            <ul>
                <li><a href="index.html">Beranda</a></li>
                <li><a href="tentang.php">Tentang</a></li>
                <li><a href="donasi.html">Donasi</a></li>
                <li><a href="riwayat_donasi.php">Riwayat Donasi</a></li>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section class="gallery">
            <h2>Galeri Gambar</h2>
            <div class="image-container">
                <?php include 'fetch_gallery_images.php'; ?> <!-- Memanggil skrip PHP untuk mengambil daftar gambar dari galeri -->
            </div>
        </section>
    </main>

    <footer>
        <p class="gans">Copyrights &copy; 2023 Portal Donasi </p>
    </footer>
</body>
</html>
