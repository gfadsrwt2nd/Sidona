<?php
// Konfigurasi koneksi database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sidona';

// Buat koneksi ke database
$conn = new mysqli($host, $username, $password, $database);

// Periksa koneksi
if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}

// Query untuk mengambil data donasi dari tabel "donations"
$sql = "SELECT * FROM donations";

$result = $conn->query($sql);


if ($result->num_rows > 0) {
    // Output data dari setiap baris
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $no . "</td>";
        echo "<td>" . $row['sender_name'] . "</td>";
        echo "<td>" . $row['donation_date'] . "</td>";
        echo "<td>Rp. " . $row['amount'] . "</td>";

        // Pastikan kolom 'payment_method' tersedia sebelum mengakses nilainya
        if (isset($row['payment_method'])) {
            echo "<td>" . $row['payment_method'] . "</td>";
        } else {
            echo "<td>Metode Pembayaran Tidak Diketahui</td>";
        }

        echo "<td>" . $row['message'] . "</td>";
        echo "</tr>";
        $no++;
    }
} else {
    echo "<tr><td colspan='5'>Tidak ada data donasi.</td></tr>";
}

// Tutup koneksi
$conn->close();
?>
