<!DOCTYPE html>
<html>
<head>
    <title>Galeri Foto</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include 'inc/header.php'; ?>

    <!-- Tambahkan div utama sebagai container konten -->
    <div class="main-content" style="text-align: justify-all;">
        <center>
        <h2>Galeri Foto</h2>
        <hr>
        <br><br>
        <tan>
        <?php
        // Koneksi ke database (gantikan dengan detail koneksi Anda)
        $conn = mysqli_connect('localhost', 'root', '', 'db_donasi');

        // Periksa koneksi
        if (mysqli_connect_errno()) {
            echo "Koneksi database gagal: " . mysqli_connect_error();
            exit();
        }

        // Query untuk mengambil semua data foto dari tabel galeri_foto
        $query = "SELECT * FROM galeri_foto";
        $result = mysqli_query($conn, $query);

        // Periksa apakah ada data foto
        if (mysqli_num_rows($result) > 0) {
            echo '<div class="galeri-container">';
            while ($row = mysqli_fetch_assoc($result)) {
                // Menampilkan gambar foto
                echo '<div class="galeri-item">';
                echo '<img src="' . $row['url_foto'] . '" alt="Foto Galeri">';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo "Belum ada foto di galeri.";
        }

        // Tutup koneksi
        mysqli_close($conn);
        ?>
        </center>
        </tan>
    </div>
    <br><br>
    <hr>

    <!-- Tambahkan footer di sini -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Hak Cipta Dilindungi.</p>
    </footer>
</body>
</html>
