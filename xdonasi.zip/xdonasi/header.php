<!DOCTYPE html>
<html>
<head>
    <title>Tentang Baturaja Bersedekah</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Tambahkan header di sini -->
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="tentang.php">Tentang</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <!-- Tambahkan div utama sebagai container konten -->
    <div class="main-content">
