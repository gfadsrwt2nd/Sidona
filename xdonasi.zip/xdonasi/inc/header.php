<!DOCTYPE html>
<html>
<head>
    <title>Tentang | Baturaja Bersedekah</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Tambahkan header di sini -->
    <header>
        <nav style="text-align: center;">
            <ul>
                <rexa><li><a href="index.php">Beranda</a></li></rexa>
                <rexa><li><a href="donatur.php">Donatur</a></li></rexa>
                <rexa><li><a href="tentang.php">Tentang</a></li></rexa>
                <rexa><li><a href="berita.php">Berita</a></li></rexa>
                <rexa><li><a href="galeri.php">Galeri</a></li></rexa>
                <rexa><li><a href="kontak.php">Kontak</a></li></rexa>
            </ul>
        </nav>
    </header>

    <!-- Tambahkan div utama sebagai container konten -->
    <div class="main-content">
