    </div> <!-- Penutup div utama -->

    <!-- Tambahkan footer di sini -->
    <footer>
        <p style="font-family: sans-serif; color: black;">Copyrights &copy; Baturaja Bersedekah <?php echo date('Y'); ?> </p>
    </footer>
</body>
</html>
