<!DOCTYPE html>
<html>
<head>
    <title>Halaman Berita</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<style type="text/css">
/* Gaya untuk mengatur susunan gambar dan teks pada halaman berita */
.main-content {
    padding: 20px;
}

.berita-item {
    margin-bottom: 30px;
}

.berita-item h2 {
    margin-bottom: 10px;
}

.tanggal {
    color: #888;
    font-size: 14px;
    margin-bottom: 5px;
}

.gambar-berita {
    max-width: 100%;
    height: auto;
    margin-bottom: 10px;
}

.isi-berita {
    line-height: 1.6;
}

</style>
<body>
    <?php
    include 'inc/header.php';
    ?>

    <tan>
    <!-- Tambahkan div utama sebagai container konten -->
    <div class="mainimg">
        <?php
        // Koneksi ke database (gantikan dengan detail koneksi Anda)
        $conn = mysqli_connect('localhost', 'root', '', 'db_donasi');

        // Periksa koneksi
        if (mysqli_connect_errno()) {
            echo "Koneksi database gagal: " . mysqli_connect_error();
            exit();
        }

        // Query untuk mengambil data berita dari tabel berita (gantikan dengan nama tabel Anda)
        $query = "SELECT * FROM berita";
        $result = mysqli_query($conn, $query);

        // Periksa apakah ada data berita
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                // Menampilkan judul, tanggal, gambar, dan isi berita
                echo "<h2>" . $row['judul'] . "</h2>";
                echo "<p>Tanggal: " . $row['tanggal'] . "</p>";
                if (!empty($row['gambar_url'])) {
                    echo '<img src="' . $row['gambar_url'] . '" alt="' . $row['judul'] . '">';
                }
                echo "<p>" . $row['isi'] . "</p>";
            }
        } else {
            echo "Belum ada berita.";
        }

        // Tutup koneksi
        mysqli_close($conn);
        ?>
    </div>

    </tan>
    <div>
        
    </div>
    <!-- Tambahkan footer di sini -->
<?php
include 'inc/footer.php';
?>
