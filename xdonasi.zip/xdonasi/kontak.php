<!DOCTYPE html>
<html>
<head>
    <title>Hubungi Kami</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'inc/header.php'; ?>

    <!-- Tambahkan div utama sebagai container konten -->
    <div class="main-content">
        <center>
        <h2>Hubungi Kami</h2>
        <p>Jika Anda memiliki pertanyaan atau ingin berkontribusi, silakan isi formulir di bawah ini untuk menghubungi kami.</p>
        </center>
        
        <form action="proses_kontak.php" method="post">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="pesan">Pesan:</label>
            <textarea id="pesan" name="pesan" rows="4" required></textarea>

            <button type="submit">Kirim Pesan</button>
        </form>
    </div>

    <!-- Tambahkan footer di sini -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Hak Cipta Dilindungi.</p>
    </footer>
</body>
</html>
