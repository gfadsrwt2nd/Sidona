<?php
// Koneksi ke database (gantikan dengan detail koneksi Anda)
$conn = mysqli_connect('localhost', 'root', '', 'db_donasi');

// Periksa koneksi
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit();
}

// Memastikan form telah dikirim dan data telah diisi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $pesan = $_POST['pesan'];

    // Query untuk menyimpan data pesan ke dalam tabel kontak_messages
    $query = "INSERT INTO kontak_messages (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";

    if (mysqli_query($conn, $query)) {
        // Jika data berhasil disimpan, kirimkan pesan sukses
        echo "Pesan Anda berhasil terkirim. Terima kasih atas kontribusi Anda!";
        echo "<br>";
        echo "<a style='font-family:serif;' href='kontak.php'> Kembali</a>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

// Tutup koneksi
mysqli_close($conn);
?>
