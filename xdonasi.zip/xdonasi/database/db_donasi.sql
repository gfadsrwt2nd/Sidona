-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jul 2023 pada 13.40
-- Versi server: 10.4.13-MariaDB
-- Versi PHP: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_donasi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`) VALUES
(1, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `id` int(25) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `series_id` varchar(60) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `admin_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `user_name`, `password`, `series_id`, `remember_token`, `expires`, `admin_type`) VALUES
(1, 'admin', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'MyG5Xw2I12EWdJeD', '$2y$10$XL/RhpCz.uQoWE1xV77Wje4I4ker.gtg7YV4yqNwLZfzIYnP7E8Na', '2019-08-22 01:12:33', 'admin'),
(2, 'superadmin', '$2y$10$eo7.w0Ttuy8mOBMvDlGqDeewQERkXu//7qO3jXp5NC76LwfAZpNrO', 'rvuWJHMd5LTxLC2J', '$2y$10$LDUi4w/UAM2PgfMoKkLo4.igJX39G5/WQOEDHRaDy3y2KZeIxXggm', '2019-02-16 22:39:57', 'super');

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `isi` text NOT NULL,
  `gambar_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `tanggal`, `isi`, `gambar_url`) VALUES
(1, 'Aisyah Sulit Bernafas', '2023-07-03', 'Aisyah anak kecil berumur 6 tahun di oku timur mengalami susah bernafas akibat penyakit yang ia derita.', 'img/gc2.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `donatur`
--

CREATE TABLE `donatur` (
  `id_donatur` int(11) NOT NULL,
  `nama_donatur` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tanggal_donasi` date NOT NULL,
  `jumlah_donasi` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `donatur_info`
--

CREATE TABLE `donatur_info` (
  `id_donatur` int(11) NOT NULL,
  `nama_donatur` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `foto_profil` varchar(255) DEFAULT NULL,
  `informasi_lainnya` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `donatur_info`
--

INSERT INTO `donatur_info` (`id_donatur`, `nama_donatur`, `email`, `foto_profil`, `informasi_lainnya`) VALUES
(1, 'Nopran', 'nopran@gmail.com', 'img/donatur/1.png', '0812345678'),
(2, 'mita', 'mita@gmail.com', 'img/donatur/2.png', '12312412');

-- --------------------------------------------------------

--
-- Struktur dari tabel `donatur_kategori`
--

CREATE TABLE `donatur_kategori` (
  `id_donatur` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `galeri_foto`
--

CREATE TABLE `galeri_foto` (
  `id_foto` int(11) NOT NULL,
  `id_proyek` int(11) NOT NULL,
  `judul_foto` varchar(100) NOT NULL,
  `url_foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `galeri_foto`
--

INSERT INTO `galeri_foto` (`id_foto`, `id_proyek`, `judul_foto`, `url_foto`) VALUES
(1, 1, 'Gempa Cianjur', 'img/dh2.jpg'),
(2, 2, 'Berbagi Bersama', 'img/dh1.png'),
(3, 3, 'aasdas', 'img/gc1.jpg'),
(4, 4, 'dgfdwrewq', 'img/gc2.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_donasi`
--

CREATE TABLE `kategori_donasi` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kontak_messages`
--

CREATE TABLE `kontak_messages` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kontak_messages`
--

INSERT INTO `kontak_messages` (`id`, `nama`, `email`, `pesan`, `tanggal`) VALUES
(1, 'rexa', 'rusdioey@gmail.com', 'asdasdas', '2023-07-29 10:50:33'),
(3, 'rexa', 'test@test.com', 'test', '2023-07-29 10:53:35'),
(4, 'rexa', 'test@test.com', 'test', '2023-07-29 10:56:29'),
(5, 'rexa', 'test@test.com', 'test', '2023-07-29 10:56:46'),
(6, 'rexa', 'test@test.com', 'test', '2023-07-29 10:57:33'),
(7, 'misal', 'misalkan@gmail.com', 'misalkan', '2023-07-29 10:57:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_keuangan`
--

CREATE TABLE `laporan_keuangan` (
  `id_laporan` int(11) NOT NULL,
  `id_proyek` int(11) NOT NULL,
  `id_transaksi` int(11) DEFAULT NULL,
  `tanggal_laporan` date NOT NULL,
  `pendapatan` decimal(10,2) NOT NULL,
  `biaya_operasional` decimal(10,2) NOT NULL,
  `jumlah_donatur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `metode_pembayaran`
--

CREATE TABLE `metode_pembayaran` (
  `id_metode` int(11) NOT NULL,
  `nama_metode` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `aktif` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan_donasi`
--

CREATE TABLE `pesan_donasi` (
  `id_pesan` int(11) NOT NULL,
  `id_donatur` int(11) NOT NULL,
  `id_proyek` int(11) NOT NULL,
  `isi_pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `proyek_donasi`
--

CREATE TABLE `proyek_donasi` (
  `id_proyek` int(11) NOT NULL,
  `nama_proyek` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `target_donasi` decimal(10,2) NOT NULL,
  `jumlah_donasi` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `proyek_donasi`
--

INSERT INTO `proyek_donasi` (`id_proyek`, `nama_proyek`, `deskripsi`, `target_donasi`, `jumlah_donasi`) VALUES
(1, 'Bantu Konban Banjir', 'Mari bersama kita bantu korban banjir di sulawesi', '5000000.00', '1000000.00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tim_donasi`
--

CREATE TABLE `tim_donasi` (
  `id_tim` int(11) NOT NULL,
  `nama_tim` varchar(100) NOT NULL,
  `deskripsi_tim` text NOT NULL,
  `jumlah_anggota` int(11) NOT NULL,
  `id_proyek` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_donasi`
--

CREATE TABLE `transaksi_donasi` (
  `id_transaksi` int(11) NOT NULL,
  `id_proyek` int(11) DEFAULT NULL,
  `nama_donatur` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nomor_telepon` varchar(20) DEFAULT NULL,
  `jumlah_donasi` decimal(10,2) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `tanggal_donasi` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `donatur`
--
ALTER TABLE `donatur`
  ADD PRIMARY KEY (`id_donatur`);

--
-- Indeks untuk tabel `donatur_info`
--
ALTER TABLE `donatur_info`
  ADD PRIMARY KEY (`id_donatur`);

--
-- Indeks untuk tabel `donatur_kategori`
--
ALTER TABLE `donatur_kategori`
  ADD PRIMARY KEY (`id_donatur`,`id_kategori`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `galeri_foto`
--
ALTER TABLE `galeri_foto`
  ADD PRIMARY KEY (`id_foto`);

--
-- Indeks untuk tabel `kategori_donasi`
--
ALTER TABLE `kategori_donasi`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kontak_messages`
--
ALTER TABLE `kontak_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `laporan_keuangan`
--
ALTER TABLE `laporan_keuangan`
  ADD PRIMARY KEY (`id_laporan`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD KEY `username` (`username`);

--
-- Indeks untuk tabel `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  ADD PRIMARY KEY (`id_metode`);

--
-- Indeks untuk tabel `pesan_donasi`
--
ALTER TABLE `pesan_donasi`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indeks untuk tabel `proyek_donasi`
--
ALTER TABLE `proyek_donasi`
  ADD PRIMARY KEY (`id_proyek`);

--
-- Indeks untuk tabel `tim_donasi`
--
ALTER TABLE `tim_donasi`
  ADD PRIMARY KEY (`id_tim`);

--
-- Indeks untuk tabel `transaksi_donasi`
--
ALTER TABLE `transaksi_donasi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `donatur`
--
ALTER TABLE `donatur`
  MODIFY `id_donatur` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `donatur_info`
--
ALTER TABLE `donatur_info`
  MODIFY `id_donatur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `galeri_foto`
--
ALTER TABLE `galeri_foto`
  MODIFY `id_foto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `kategori_donasi`
--
ALTER TABLE `kategori_donasi`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kontak_messages`
--
ALTER TABLE `kontak_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `laporan_keuangan`
--
ALTER TABLE `laporan_keuangan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  MODIFY `id_metode` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pesan_donasi`
--
ALTER TABLE `pesan_donasi`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `proyek_donasi`
--
ALTER TABLE `proyek_donasi`
  MODIFY `id_proyek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tim_donasi`
--
ALTER TABLE `tim_donasi`
  MODIFY `id_tim` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transaksi_donasi`
--
ALTER TABLE `transaksi_donasi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `donatur`
--
ALTER TABLE `donatur`
  ADD CONSTRAINT `donatur_ibfk_1` FOREIGN KEY (`id_donatur`) REFERENCES `donatur_info` (`id_donatur`);

--
-- Ketidakleluasaan untuk tabel `donatur_kategori`
--
ALTER TABLE `donatur_kategori`
  ADD CONSTRAINT `donatur_kategori_ibfk_1` FOREIGN KEY (`id_donatur`) REFERENCES `donatur` (`id_donatur`),
  ADD CONSTRAINT `donatur_kategori_ibfk_2` FOREIGN KEY (`id_kategori`) REFERENCES `kategori_donasi` (`id_kategori`);

--
-- Ketidakleluasaan untuk tabel `transaksi_donasi`
--
ALTER TABLE `transaksi_donasi`
  ADD CONSTRAINT `transaksi_donasi_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `laporan_keuangan` (`id_laporan`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
