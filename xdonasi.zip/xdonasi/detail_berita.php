<!DOCTYPE html>
<html>
<head>
    <title>Detail Berita</title>
</head>
<body>
    <?php
        // Cek apakah parameter 'id' telah diberikan
        if (isset($_GET['id'])) {
            // Ambil id berita dari parameter 'id'
            $id_berita = $_GET['id'];

            // Koneksi ke database (ganti dengan konfigurasi koneksi Anda)
            $db_host = "localhost";
            $db_username = "root";
            $db_password = "";
            $db_name = "db_donasi";

            $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
            if (!$conn) {
                die("Koneksi ke database gagal: " . mysqli_connect_error());
            }

            // Query untuk mengambil data berita berdasarkan id
            $query = "SELECT * FROM berita WHERE id_berita = $id_berita";
            $result = mysqli_query($conn, $query);

            // Tampilkan detail berita jika ditemukan
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                echo '<h1>' . $row['judul'] . '</h1>';
                echo '<p>' . $row['isi_berita'] . '</p>';
            } else {
                echo "Berita tidak ditemukan.";
            }

            // Tutup koneksi ke database
            mysqli_close($conn);
        } else {
            echo "Parameter 'id' tidak ditemukan.";
        }
    ?>
</body>
</html>
