<?php
include 'inc/header.php';
?>


<div class="content" style="text-align: justify;">
    <center>
    <h1>Tentang Kami</h1>
    <br><br><br>
        
    <img src="img/bg.jpeg">
    <p>
        Selamat datang di situs web kami! mari berbagi bersama kami, bersama kita mewujudkan kebaikan di indonesia.
    </p>
        
    </center></div>

    
<?php
include 'inc/footer.php';
?>