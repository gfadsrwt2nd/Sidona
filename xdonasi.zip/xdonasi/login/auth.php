<?php
/*
 * code untuk pengecekan session login
 **/

/*
 * start session
 **/
session_start();

/*
 * periksa session
 * jika tidak ada session 'admin' maka kita anggap belum login
 **/
if (!isset($_SESSION['admin'])) {
	header('location: index.php');
}
