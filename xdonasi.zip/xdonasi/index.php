
<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Donasi - Beranda</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url(.///img/gc1.jpg);">
    <header>
        <h1 style="text-align: center;">Baturaja Bersedekah</h1>
        <hr>
        
        <?php
        include 'inc/header.php';
        ?>

    </header>
    <main>
        <!-- Isi dari halaman beranda -->
    </main>
    <?php
    include 'inc/footer.php';
    ?>
</body>
</html>
