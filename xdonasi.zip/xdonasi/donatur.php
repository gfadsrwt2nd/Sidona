<!DOCTYPE html>
<html>
<head>
    <title>Halaman Donatur</title>
    <!-- Hubungkan dengan file CSS Anda -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'inc/header.php'; ?>

    <!-- Tambahkan div utama sebagai container konten -->
    <div class="main-content">
        <h2>Daftar Donatur</h2>

        <?php
        // Koneksi ke database (gantikan dengan detail koneksi Anda)
        $conn = mysqli_connect('localhost', 'root', '', 'db_donasi');

        // Periksa koneksi
        if (mysqli_connect_errno()) {
            echo "Koneksi database gagal: " . mysqli_connect_error();
            exit();
        }

        // Query untuk mengambil data donatur dari tabel donatur_info
        $query = "SELECT * FROM donatur_info";
        $result = mysqli_query($conn, $query);

        // Periksa apakah ada data donatur
        if (mysqli_num_rows($result) > 0) {
            echo '<ul>';
            while ($row = mysqli_fetch_assoc($result)) {
                // Menampilkan informasi donatur dan foto profil
                echo '<li>';
                echo '<img src="' . $row['foto_profil'] . '" alt="Foto Profil ' . $row['nama_donatur'] . '">';
                echo $row['nama_donatur'] . ' - ' . $row['email'];
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo "Belum ada donatur.";
        }

        // Tutup koneksi
        mysqli_close($conn);
        ?>

        
    </div>

    <!-- Tambahkan footer di sini -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Hak Cipta Dilindungi.</p>
    </footer>
</body>
</html>
